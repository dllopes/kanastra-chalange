// src/App.tsx
import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Layout, NoMatch, FileUploader, Table } from './components';

const App = () => {
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const handleFileUpload = async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('http://localhost:3000/files', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        setUploadStatus('File uploaded successfully');
        console.log('File uploaded successfully:', data);
      } else {
        setUploadStatus('File upload failed');
        console.error('File upload failed');
      }
    } catch (error) {
      setUploadStatus('An error occurred during file upload');
      console.error('An error occurred during file upload:', error);
    }
  };

  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route
          index
          element={
            <>
              <FileUploader onFileUpload={handleFileUpload} />
              {uploadStatus && <p>{uploadStatus}</p>}
            </>
          }
        />
        <Route path="table" element={<Table />} />
        <Route path="*" element={<NoMatch />} />
      </Route>
    </Routes>
  );
};

export default App;
