// src/components/file-uploader.tsx
import React, { useState } from 'react';

type FileUploaderProps = {
  onFileUpload: (file: File) => void;
};

const FileUploader = ({ onFileUpload }: FileUploaderProps) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files ? e.target.files[0] : null;
    setSelectedFile(file);
  };

  const handleUpload = () => {
    if (selectedFile) {
      onFileUpload(selectedFile);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div>
        <label htmlFor="file" className="sr-only">
          Choose a file
        </label>
        <input
          id="file"
          type="file"
          accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv"
          onChange={handleFileChange}
        />
      </div>
      {selectedFile && (
        <section>
          <p className="pb-6">File details:</p>
          <ul>
            <li>Name: {selectedFile.name}</li>
            <li>Type: {selectedFile.type}</li>
            <li>Size: {selectedFile.size} bytes</li>
          </ul>
        </section>
      )}
      {selectedFile && (
        <button
          onClick={handleUpload}
          className="rounded-lg bg-green-800 text-white px-4 py-2 border-none font-semibold"
        >
          Upload the file
        </button>
      )}
    </div>
  );
};

export { FileUploader };
